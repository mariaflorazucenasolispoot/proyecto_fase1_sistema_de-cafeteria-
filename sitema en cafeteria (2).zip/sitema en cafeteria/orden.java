import java.util.ArrayList;
import java.util.List;

public class Orden {
    private List<Producto> productos;
    private Cliente cliente;

    public Orden(Cliente cliente) {
        this.productos = new ArrayList<>();
        this.cliente = cliente;
    }

    public void agregarProducto(Producto producto) {
        productos.add(producto);
    }

    public float calcularTotal() {
        float total = 0;
        for (Producto producto : productos) {
            total += producto.getPrecio(); // CORRECTO
        }
        return total;
    }

    public List<Producto> getProductos() {
        return productos;
    }

    public Cliente getCliente() {
        return cliente;
    }

    @Override
    public String toString() {
        return String.format("Orden de %s - Total: $%.2f - Productos: %d",
                cliente.getNombre(), calcularTotal(), productos.size());
    }
}