import java.util.ArrayList;
import java.util.List;

public class Menu {
    private List<Producto> productos;

    public Menu() {
        this.productos = new ArrayList<>();
    }

    public void agregarProducto(Producto producto) {
        productos.add(producto);
    }

    public List<Producto> obtenerProductos() {
        return new ArrayList<>(productos); // Retorna copia para encapsulación
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder("Menú:\n");
        for (Producto producto : productos) {
            sb.append("- ").append(producto).append("\n");
        }
        return sb.toString();
    }
}