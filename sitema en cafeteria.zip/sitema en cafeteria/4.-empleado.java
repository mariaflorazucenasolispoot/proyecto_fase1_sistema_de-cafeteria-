public class Empleado {
    public String nombre;

    public Empleado(String nombre) {
        this.nombre = nombre;
    }

    public void prepararOrden(Orden orden) {
        System.out.println("Empleado " + nombre + " está preparando la orden: " + orden);
    }

    // Getter y setter
    public String getNombre() { return nombre; }
    public void setNombre(String nombre) { this.nombre = nombre; }
}