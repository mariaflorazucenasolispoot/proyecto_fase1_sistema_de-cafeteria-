public class Notificador implements OrdenObserver {
    public void notificar(Cliente cliente, String mensaje) {
        System.out.println("📧 Notificación a " + cliente.nombre + ": " + mensaje);
    }

    @Override
    public void actualizar(Orden orden) {
        notificar(orden.getCliente(), "Tu orden está lista: " + orden);
    }
}