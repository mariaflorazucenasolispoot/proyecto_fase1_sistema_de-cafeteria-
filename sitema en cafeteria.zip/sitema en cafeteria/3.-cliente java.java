public class Cliente {
    public String nombre;

    public Cliente(String nombre) {
        this.nombre = nombre;
    }

    public void realizarPedido(Orden orden) {
        System.out.println("Cliente " + nombre + " ha realizado un pedido: " + orden);
    }

    // Getter y setter
    public String getNombre() { return nombre; }
    public void setNombre(String nombre) { this.nombre = nombre; }
}