public class Cafeteria {
    private static Cafeteria instance;
    private Menu menu;

    private Cafeteria() {
        this.menu = new Menu();
    }

    public static Cafeteria getInstance() {
        if (instance == null) {
            instance = new Cafeteria();
        }
        return instance;
    }

    public Orden crearOrden(Cliente cliente) {
        return new Orden(cliente);
    }

    public Menu getMenu() {
        return menu;
    }

    public void mostrarMenu() {
        System.out.println(menu);
    }
}