public interface OrdenObserver {
    void actualizar(Orden orden);
}