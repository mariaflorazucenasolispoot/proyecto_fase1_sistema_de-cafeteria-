public class Main {
    public static void main(String[] args) {
        // Crear cafetería (Singleton)
        Cafeteria cafeteria = Cafeteria.getInstance();

        // Crear productos y agregarlos al menú
        Producto cafe = new Producto("Café", 2.5f, "Café negro");
        Producto pastel = new Producto("Pastel", 3.0f, "Pastel de chocolate");
        cafeteria.getMenu().agregarProducto(cafe);
        cafeteria.getMenu().agregarProducto(pastel);

        System.out.println("=== MENÚ DE LA CAFETERÍA ===");
        cafeteria.mostrarMenu();

        // Crear cliente y notificador
        Cliente cliente = new Cliente("Juan Pérez");
        Notificador notificador = new Notificador();

        // Crear orden
        Orden orden = cafeteria.crearOrden(cliente);
        orden.agregarProducto(cafe);
        orden.agregarProducto(pastel);

        // Procesar pedido
        cliente.realizarPedido(orden);

        Empleado empleado = new Empleado("María Gómez");
        empleado.prepararOrden(orden);

        // Notificar
        notificador.actualizar(orden);

        System.out.println("\n=== RESUMEN ===");
        System.out.println(orden);
    }
}